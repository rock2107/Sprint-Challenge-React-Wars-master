# Answers

1. What is React JS and what problems does it solve? Support your answer with concepts introduced in class and from your personal research on the web.

1. Describe component state.

1. Describe props.

1. What are side effects, and how do you sync effects in a React component to changes of certain state or props?
